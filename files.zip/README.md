# Beefy · Aggression Explorer

A static web app for traders to explore the Beefy cricket model's aggression
dictionary — heatmap + line cross-section views of the gamestate spline across
all submodels, both innings, spin & seam, with components (intercept, year
trend) toggleable in real time.

Hosted free on GitHub Pages. No backend.

---

## ⚠ The bundled data is synthetic

`data/agg_data.json` shipped in this repo is **a synthetic placeholder**
generated so you can preview the UI before running the real export. The
shapes match production but the values are fake. Replace it with the real
export (instructions below) before sharing the app.

---

## Repository layout

```
.
├── index.html                  # the web app — single file, no build step
├── data/
│   └── agg_data.json           # exported data, ~5–15 MB. NOT checked in here
│                               # — you generate it from Jupyter (see below)
├── export_aggression_data.py   # the export script (run in Jupyter)
└── README.md
```

---

## How to deploy (first time)

1. **Create a new GitHub repo** (public or private with Pages enabled on
   your plan). Push everything in this folder to it except `data/agg_data.json`
   (you'll create that next).

2. **In the trader Jupyter env**, open a notebook with the cricket `df` loaded
   and the helper functions (`add_column_to_df`) available, then run:

   ```python
   %run export_aggression_data.py
   ```

   This writes `agg_data.json` to the working directory. It will be ~5–15 MB.

3. **Move that file into the repo** at `./data/agg_data.json` and commit:

   ```bash
   mkdir -p data
   mv /path/to/agg_data.json ./data/
   git add data/agg_data.json
   git commit -m "Refresh aggression data"
   git push
   ```

4. **Enable GitHub Pages**: repo Settings → Pages → Source = "Deploy from a
   branch" → Branch = `main` (folder = `/ (root)`). Save. After ~1 minute
   your app is live at `https://<your-user>.github.io/<repo-name>/`.

That's it. No build step, no CI, no server.

---

## How to refresh the data (after every model retrain)

Re-run step 2 in Jupyter, drop the new `agg_data.json` into `./data/`,
commit, push. GitHub Pages will redeploy automatically within a minute.

If you want this fully automated, add a tiny GitHub Action that pulls the
file from a shared location — but for v1 a manual push is fine.

---

## Local preview (optional)

To preview without pushing:

```bash
cd /path/to/repo
python3 -m http.server 8000
# open http://localhost:8000
```

The app reads `data/agg_data.json` via fetch — opening `index.html`
directly via `file://` will fail due to CORS. Always serve via http.

---

## What the app shows

- **Heatmap**: aggression value across `wickets × overs`, with a divergent
  colourscale centered on 0 for logit view and a sequential scheme for
  probability view.
- **Line cross-section** (lower panel): by default, all 10 wicket lines
  overlaid; click a row in the heatmap to focus on that wicket level.
  Double-click the line plot to return to "all".
- **KPI strip**: shows selected submodel, the intercept used, the year-trend
  contribution at the selected year, min/max in the current view, and the
  count of non-zero cells.
- **Components toggles**: independently turn on/off intercept and year
  trend so you can see the raw spline alone, or the fully-built
  `{submodel}_aggression` value as it appears in `df`.
- **Sparse-cell masking**: optionally grey out cells where
  `outside_aggression_dictionary.json` flags the gamestate as data-sparse.

### Status banners

- **Spin** at any time: experimental — formula not fully validated per
  `cricket_json_reference.md`.
- **2nd innings**: RRR bucket→index mapping unresolved. The slider picks a
  bucket index, not a confirmed RRR value. Intercept is estimated using
  the mean across the RRR axis (approximate).
- **Last over** (over 20 in T20): the main spline returns 0 here; the
  proper last-over spline lives in a separate dict that isn't yet
  documented. Don't trade on over 20 values from this view.

---

## Roadmap (next modules)

- **Matchups for a specific game** — drop in a `match_id`, pull both XIs,
  show every batter × bowler matchup ranked by absolute logit differential.
- **Play-in graphs** — the `cbf_spline` and `partnership_balls` splines
  visualised per submodel, per format, per innings.

Both will follow the same pattern: a small Python export script + a new
page in this repo. The infrastructure here is reusable.
