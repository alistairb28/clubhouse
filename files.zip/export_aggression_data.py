"""
export_aggression_data.py
-------------------------
Run this ONCE in the trader Jupyter env to produce `agg_data.json`
for the aggression dictionary web app.

Outputs a single JSON file containing:
  - All 6 submodel splines × {first, second} innings × {spin, seam}
  - Empirically-derived intercepts per (submodel, bowl_style) from df
  - Year trend dict (year_dict.json) per submodel per prior group
  - Outside aggression masks per (innings, bowl_style)
  - Metadata (year_float_min, last_t20_y, build timestamp)

The output is consumed by the static web app — no live Python after export.

USAGE
-----
    %run export_aggression_data.py
    # writes ./agg_data.json   (roughly 5–15 MB)

Then commit agg_data.json into the web app repo under /data/agg_data.json.
"""

import json
import os
from datetime import datetime

import numpy as np
import pandas as pd

# -------------------------------------------------------------------- paths
BASE = "/data/trader_jupyter/notebooks/beefy_ratings/men"
AGG_PATH      = f"{BASE}/aggression_dictionary.json"
OUT_AGG_PATH  = f"{BASE}/outside_aggression_dictionary.json"
YEAR_PATH     = f"{BASE}/year_dict.json"

OUTPUT_PATH = "./agg_data.json"

SUBMODELS = ["wnb", "out", "is_bnd", "bnd_runs", "not_dot", "double"]
STYLES    = ["spin", "seam"]
INNINGS   = ["first", "second"]


# -------------------------------------------------------- load source files
print("Loading JSON files...")
with open(AGG_PATH, "r") as f:
    agg_dict = json.load(f)
with open(OUT_AGG_PATH, "r") as f:
    out_agg_dict = json.load(f)
with open(YEAR_PATH, "r") as f:
    year_dict = json.load(f)


# ----------------------------------------- empirically derive intercepts
# For seam first innings the doc-confirmed formula is:
#     {sm}_aggression = intercept + agg_dict['first'][sm]['runs']['seam'][w][o][0] + year_dict
# So:  intercept = aggression - spline - year_dict_value
# We compute it as the modal value of (aggression - spline - year_dict) over
# clean rows (year 2010 baseline, where year_dict ≈ 0) to avoid year noise.
#
# We do this PER (submodel, bowl_style) and also per innings, even though spin
# / 2nd-innings formulas are not fully validated — we expose the values in the
# UI with a warning so traders can see the working numbers and judge.

print("Deriving intercepts from df...")

# We need: {sm}_aggression, over, wickets, innings, bowl_style, {sm}_year_dict
# Plus we need to be on a baseline-year-ish row so year_dict is small.
# Use 2010 rows where available.

# Load year_dict columns we need
required_cols = (
    [f"{sm}_aggression" for sm in SUBMODELS]
    + [f"{sm}_year_dict" for sm in SUBMODELS]
    + ["over", "wickets", "innings", "bowl_style", "year_float", "last_over"]
)

# add_column_to_df is exposed in the trader env
for col in required_cols:
    if col not in df.columns:
        df = add_column_to_df(df, col)  # noqa: F821 (df / add_column_to_df from session)

# Restrict to clean rows: non-last-over, in-range overs/wickets, no NaN
sample = df[
    (df["last_over"] == 0)
    & df["over"].between(0, 49)
    & df["wickets"].between(0, 9)
    & df["innings"].isin([0, 1])
    & df["bowl_style"].isin(STYLES)
].copy()

intercepts = {}  # intercepts[innings][bowl_style][submodel] = float

for inn_idx, inn_key in enumerate(INNINGS):
    intercepts[inn_key] = {}
    for style in STYLES:
        intercepts[inn_key][style] = {}
        sub = sample[(sample["innings"] == inn_idx) & (sample["bowl_style"] == style)]
        if len(sub) == 0:
            for sm in SUBMODELS:
                intercepts[inn_key][style][sm] = None
            continue

        for sm in SUBMODELS:
            agg_col = f"{sm}_aggression"
            yr_col  = f"{sm}_year_dict"

            # spline lookup for first innings shape (10, 70, 1)
            # for second innings shape (43, 70, 10) → we collapse over rrr_bucket dimension
            arr = np.array(agg_dict[inn_key][sm]["runs"][style])

            if inn_key == "first":
                # arr[w, o, 0]
                w = sub["wickets"].astype(int).values
                o = sub["over"].astype(int).values
                # bounds-safe mask
                ok = (w < arr.shape[0]) & (o < arr.shape[1])
                if ok.sum() == 0:
                    intercepts[inn_key][style][sm] = None
                    continue
                spline_vals = arr[w[ok], o[ok], 0]
                agg_vals = sub[agg_col].values[ok]
                yr_vals  = sub[yr_col].values[ok]
                residual = agg_vals - spline_vals - yr_vals
            else:
                # second innings: bucket dimension unresolved, but we can still
                # bound the intercept by using the mean across the bucket axis
                # — this gives an APPROXIMATE intercept. Flagged as such in UI.
                w = sub["wickets"].astype(int).values
                o = sub["over"].astype(int).values
                ok = (w < arr.shape[2]) & (o < arr.shape[1])
                if ok.sum() == 0:
                    intercepts[inn_key][style][sm] = None
                    continue
                # mean over the unknown RRR bucket axis
                mean_spline = arr.mean(axis=0)  # shape (70, 10) — over × wickets
                spline_vals = mean_spline[o[ok], w[ok]]
                agg_vals = sub[agg_col].values[ok]
                yr_vals  = sub[yr_col].values[ok]
                residual = agg_vals - spline_vals - yr_vals

            # Robust central value
            valid = residual[~np.isnan(residual)]
            if len(valid) == 0:
                intercepts[inn_key][style][sm] = None
            else:
                intercepts[inn_key][style][sm] = float(np.median(valid))

print("Intercepts derived:")
for inn in INNINGS:
    for st in STYLES:
        for sm in SUBMODELS:
            v = intercepts[inn][st][sm]
            print(f"  {inn:7s} {st:5s} {sm:10s}  intercept = {v}")


# ----------------------------------------------------- year trend digest
# year_dict shape: submodel → innings → prior_group → array (length ~171)
# For the UI we want a representative "average across prior groups" plot and
# the raw per-group values for power users.
print("\nProcessing year trend...")
year_out = {}
for sm in SUBMODELS:
    year_out[sm] = {}
    for inn in INNINGS:
        if sm not in year_dict or inn not in year_dict[sm]:
            year_out[sm][inn] = {"per_group": {}, "mean": []}
            continue
        groups = year_dict[sm][inn]
        per_group = {g: list(map(float, arr)) for g, arr in groups.items()}
        # mean across groups
        stacked = np.array([per_group[g] for g in per_group])
        mean_arr = stacked.mean(axis=0).tolist() if len(stacked) > 0 else []
        year_out[sm][inn] = {"per_group": per_group, "mean": mean_arr}


# ----------------------------------------- compact aggression arrays
print("Packaging aggression arrays...")
agg_out = {}
for inn in INNINGS:
    agg_out[inn] = {}
    for sm in SUBMODELS:
        agg_out[inn][sm] = {}
        for style in STYLES:
            arr = np.array(agg_dict[inn][sm]["runs"][style])
            if inn == "first":
                # (10, 70, 1) → (10, 70)
                arr2 = arr[:, :, 0]
                agg_out[inn][sm][style] = arr2.round(6).tolist()
            else:
                # (43, 70, 10) — keep as-is; web app slices by RRR bucket
                agg_out[inn][sm][style] = arr.round(6).tolist()


# ----------------------------------------- outside_aggression masks
print("Packaging outside_aggression masks...")
out_mask_out = {}
for inn in INNINGS:
    out_mask_out[inn] = {}
    for style in STYLES:
        # Same shape as agg dict
        if inn in out_agg_dict and style in out_agg_dict[inn]:
            arr = np.array(out_agg_dict[inn][style])
            if inn == "first" and arr.ndim == 3:
                arr = arr[:, :, 0]
            out_mask_out[inn][style] = arr.astype(int).tolist()
        else:
            out_mask_out[inn][style] = None
    # last_over mask
    if "last_over" in out_agg_dict:
        out_mask_out["last_over"] = (
            {style: np.array(out_agg_dict["last_over"][style]).astype(int).tolist()
             for style in STYLES if style in out_agg_dict["last_over"]}
        )


# ----------------------------------------- assemble output
output = {
    "_meta": {
        "built_at": datetime.utcnow().isoformat() + "Z",
        "submodels": SUBMODELS,
        "innings_keys": INNINGS,
        "bowl_styles": STYLES,
        "year_float_min": 2010,
        "last_t20_y": int(agg_dict["first"]["wnb"]["last_t20_y"]),
        "spline_shape_first":  [10, 70],         # wickets × overs
        "spline_shape_second": [43, 70, 10],     # rrr_bucket × overs × wickets
        "notes": {
            "spin_first": "Spin formula not fully validated. Intercept derived empirically — treat as experimental.",
            "second_innings": "RRR bucket→index mapping unresolved. Intercept derived using mean over RRR axis — approximate.",
            "last_over": "Over index 19 (T20) returns 0 in main spline. Use last_over_dictionary instead — not yet documented."
        }
    },
    "aggression": agg_out,
    "intercepts": intercepts,
    "year_trend": year_out,
    "outside_mask": out_mask_out,
}

print(f"\nWriting {OUTPUT_PATH}...")
with open(OUTPUT_PATH, "w") as f:
    json.dump(output, f, separators=(",", ":"))

size_mb = os.path.getsize(OUTPUT_PATH) / 1024 / 1024
print(f"Done. Size: {size_mb:.2f} MB")
print(f"\nNext step: commit {OUTPUT_PATH} into the web app repo as /data/agg_data.json")
